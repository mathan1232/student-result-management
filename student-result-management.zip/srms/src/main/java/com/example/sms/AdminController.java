package com.example.sms;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;

@Controller
public class AdminController {

    @Autowired
    private AdminRepository adminRepo;
    @Autowired
    private NoticeRepository noticeRepo;
    @Autowired
    private ResultRepository resRepo;

    @GetMapping("/admin")
    public String showAdminLogin() {
        return "admin_login";
    }

    @PostMapping("/adminLogin")
    public String verifyAdminLogin(@RequestParam String username,
                                   @RequestParam String password,HttpSession session,
                                   Model model) {
        AdminModel admin = adminRepo.findByUsernameAndPassword(username, password);

        if (admin != null) {
        	session.setAttribute("adminUser", admin.getUsername());
        	long count = noticeRepo.count();
            model.addAttribute("noticeCount", count);
            
            long rcount = resRepo.count();
            model.addAttribute("resultCount", rcount);
            return "admin_dashboard";
        } else {
            model.addAttribute("error", "Invalid Username or Password");
            return "admin_login";
        }
    }
    

    @Autowired
    private EmailService emailService;

    private Map<String, String> otpStore = new HashMap<>();

    @GetMapping("/admin/reset-password")
    public String showResetPage(Model model) {
        return "reset-password"; // Shows OTP request form by default
    }

    @PostMapping("/admin/reset-password")
    public String handleReset(
        @RequestParam String email,
        @RequestParam(required = false) String otp,
        @RequestParam(required = false) String newPassword,
        @RequestParam String action,
        Model model) {

        if ("sendOtp".equals(action)) {
            AdminModel admin = adminRepo.findByEmail(email);
            if (admin == null) {
                model.addAttribute("error", "Email not found");
                return "reset-password";
            }

            String generatedOtp = generateOtp();
            otpStore.put(email, generatedOtp);
            emailService.sendOtpEmail(email, generatedOtp);

            model.addAttribute("email", email); // Show OTP + new password form
            return "reset-password";
        }

        if ("verifyOtp".equals(action)) {
            String storedOtp = otpStore.get(email);
            if (storedOtp == null || !storedOtp.equals(otp)) {
                model.addAttribute("error", "Invalid OTP");
                model.addAttribute("email", email);
                return "reset-password";
            }

            AdminModel admin = adminRepo.findByEmail(email);
            admin.setPassword(newPassword); // Use BCrypt in production
            adminRepo.save(admin);
            otpStore.remove(email);

            model.addAttribute("message", "Password updated successfully");
            return "reset-password"; // You can redirect to login page if preferred
        }

        model.addAttribute("error", "Invalid action");
        return "reset-password";
    }

    private String generateOtp() {
        return String.valueOf(100000 + new Random().nextInt(900000));
    }
}
