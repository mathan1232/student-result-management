package com.example.sms;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.ui.Model; // ✅ Correct


@Controller
public class ResultController {
	
	@Autowired
	ResultRepository resultRepo;
	
	@GetMapping("/student")
	public String studentLogin() {
		return "student_login";
	}
	
	@PostMapping("/StudentLogin")
	public String verifyAdminLogin(@RequestParam int StudentId, Model model) {
	    ResultModel student = resultRepo.findBystudentId(StudentId);

	    if (student != null) {
	        model.addAttribute("classList", List.of(student)); // Use list to support `th:each`
	        return "student_dashboard"; // Directly show the dashboard with this student's data
	    } else {
	        model.addAttribute("error", "Invalid Student ID");
	        return "student_login";
	    }
	}
	

	 @GetMapping("/manageResults")
	 public String viewResults(Model model) {
		 model.addAttribute("ResultModel", new ResultModel());
	     List<ResultModel> list = resultRepo.findAll();
	     model.addAttribute("resultList", list);
	        return "manage_results"; // HTML file name
	   }
	 
	 @PostMapping("/saveResult")
	 public String saveResult(@ModelAttribute ResultModel ResultMode) {
	    resultRepo.save(ResultMode);
	    return "redirect:/manageResults"; // After saving, go back to home page
	 }
	 
		@PostMapping("/deleteResult")
		 public String deleteResult(@RequestParam Long id) {
			 resultRepo.deleteById(id);
			 return "redirect:/manageResults";
		 }

}
