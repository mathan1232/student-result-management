package com.example.sms;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<AdminModel, String> {
    AdminModel findByUsernameAndPassword(String username, String password);
    AdminModel findByEmail(String email);
}
