package com.example.sms;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ResultModel {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String studentName;
	@Column(unique = true)
	private int studentId;
	private String stdclass;
	private String subcode1;
	private String subcode2;
	private String subcode3;
	private String subcode4;
	private String subcode5;
	private int mark1;
	private int mark2;
	private int mark3;
	private int mark4;
	private int mark5;
    @Column(insertable = false, updatable = false)
    private int total;
    @Column(insertable = false, updatable = false)
    private String status;

    public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public int getMark1() {
		return mark1;
	}
	public void setMark1(int mark1) {
		this.mark1 = mark1;
	}
	public int getMark2() {
		return mark2;
	}
	public void setMark2(int mark2) {
		this.mark2 = mark2;
	}
	public int getMark3() {
		return mark3;
	}
	public void setMark3(int mark3) {
		this.mark3 = mark3;
	}
	public int getMark4() {
		return mark4;
	}
	public void setMark4(int mark4) {
		this.mark4 = mark4;
	}
	public int getMark5() {
		return mark5;
	}
	public void setMark5(int mark5) {
		this.mark5 = mark5;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStdclass() {
		return stdclass;
	}
	public void setStdclass(String stdclass) {
		this.stdclass = stdclass;
	}
	public String getSubcode1() {
		return subcode1;
	}
	public void setSubcode1(String subcode1) {
		this.subcode1 = subcode1;
	}
	public String getSubcode2() {
		return subcode2;
	}
	public void setSubcode2(String subcode2) {
		this.subcode2 = subcode2;
	}
	public String getSubcode3() {
		return subcode3;
	}
	public void setSubcode3(String subcode3) {
		this.subcode3 = subcode3;
	}
	public String getSubcode4() {
		return subcode4;
	}
	public void setSubcode4(String subcode4) {
		this.subcode4 = subcode4;
	}
	public String getSubcode5() {
		return subcode5;
	}
	public void setSubcode5(String subcode5) {
		this.subcode5 = subcode5;
	}
}
