package com.example.sms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class NoticeController {
	@Autowired
	private NoticeRepository noticeRepo;
	
	@GetMapping("/manageNotices")
    public String manageNotice(Model model) {
        model.addAttribute("noticeList", noticeRepo.findAll());
        return "manages_notices"; // The name of the HTML file
    }
	
	// Save new notice
    @PostMapping("/saveNotice")
    public String saveNotice(@RequestParam String title, @RequestParam String description) {
    	NoticeModel notice = new NoticeModel(title, description);
    	noticeRepo.save(notice);
        return "redirect:/manageNotices";
    }

    // Delete notice
    @PostMapping("/deleteNotice")
    public String deleteNotice(@RequestParam Long id) {
    	noticeRepo.deleteById(id);
        return "redirect:/manageNotices";
    }

	

}
