package com.example.sms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


import org.springframework.ui.Model;

import java.util.List;

@Controller
public class ClassController {
	
	@Autowired
	private NoticeRepository noticeRepo;
	 @Autowired
	 private ClassRepository classRepository;

	 @GetMapping("/")
	    public String homePage(Model model) {
		 model.addAttribute("noticeList", noticeRepo.findAll());
	        return "index";
	    }
	 @GetMapping("/logout")
	    public String logOut() {
	        return "redirect:/";
	    }

	 @GetMapping("/manageClass")
	 public String viewClasses(Model model) {
		 model.addAttribute("Class", new ClassModel());
	     List<ClassModel> list = classRepository.findAll();
	     model.addAttribute("classList", list);
	        return "manage_classes"; // HTML file name
	   }
	 
	 @PostMapping("/delete")
	 public String deleteClass(@RequestParam Long id) {
		 classRepository.deleteById(id);
		 return "redirect:/manageClass";
	 }
	 
//	 @GetMapping("/add")
//	 public String addForm(Model model) {
//	    model.addAttribute("Class", new ClassModel());
//	    return "add_class"; // Loads add_class.html
//	 }
//     
	 @PostMapping("/save")
	 public String saveStudent(@ModelAttribute ClassModel Class) {
	    classRepository.save(Class);
	    return "redirect:/manageClass"; // After saving, go back to home page
	 }

}
